<style>
    .footer{
    background-color: rgb(16, 57, 133);
    height: 83px;
    text-align: center;
    font-family: 'Be Vietnam Pro', sans-serif;
    color: white;
    text-align: center;

}
.footer p{
    position: relative;
    top: 32px;
    left: 500px;
    margin:0;
    width:400px;

}
</style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
</head>
<body>
    <div class="footer">
     <p>Copyright &copy;Anisa Yulia 2022</p>
    </div>
</body>
</html>